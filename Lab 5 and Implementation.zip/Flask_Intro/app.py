from flask import Flask, render_template, request

app = Flask(__name__)


cheesecake_steps_data = [
    "1. Prepare the crust by mixing graham cracker crumbs, sugar, and melted butter.",
    "2. Press the mixture into the bottom of a springform pan.",
    "3. Preheat the oven to 325°F (163°C).",
    "4. In a large bowl, beat the cream cheese until smooth.",
    "5. Add sugar and beat until combined.",
    "6. Add eggs one at a time, beating well after each addition.",
    "7. Mix in sour cream, vanilla extract, and lemon juice.",
    "8. Pour the filling over the crust in the springform pan.",
    "9. Bake for 55-70 minutes or until the center is almost set.",
    "10. Turn off the oven and let the cheesecake cool in the oven for 1 hour.",
    "11. Remove from the oven and refrigerate for at least 4 hours or overnight.",
]


# Lab 4: Linked List Cheesecake Recipe Implementation
def ll_cheesecake_recipe(remove_option=None, specific_step=None):
    global cheesecake_steps_data

    class Node:
        def __init__(self, data):
            self.data = data
            self.next = None

    class LinkedList:
        def __init__(self, items=None):
            self.head = None
            if items:
                for item in items:
                    self.append(item)

        def append(self, data):
            new_node = Node(data)
            if not self.head:
                self.head = new_node
                return
            last = self.head
            while last.next:
                last = last.next
            last.next = new_node

        def display(self):
            steps = []
            current = self.head
            while current:
                steps.append(current.data)
                current = current.next
            return steps

        def remove_beginning(self):
            if not self.head:
                return None
            removed_data = self.head.data
            self.head = self.head.next
            return removed_data

        def remove_at_end(self):
            if not self.head:
                return None
            if not self.head.next:
                removed_data = self.head.data
                self.head = None
                return removed_data
            current = self.head
            while current.next.next:
                current = current.next
            removed_data = current.next.data
            current.next = None
            return removed_data

        def remove_at(self, data):
            if not self.head:
                return None
            if self.head.data == data:
                removed_data = self.head.data
                self.head = self.head.next
                return removed_data
            current = self.head
            while current.next and current.next.data != data:
                current = current.next
            if not current.next:
                return None
            removed_data = current.next.data
            current.next = current.next.next
            return removed_data

    cheesecake_list = LinkedList(cheesecake_steps_data)

    # Perform chosen operation
    removed = None
    label = "No operation performed"

    if remove_option == "beginning":
        removed = cheesecake_list.remove_beginning()
        label = "Removed at Beginning"
    elif remove_option == "end":
        removed = cheesecake_list.remove_at_end()
        label = "Removed at End"
    elif remove_option == "specific" and specific_step:
        removed = cheesecake_list.remove_at(specific_step)
        label = f"Removed Specific Step: {specific_step}"

    # Update the global steps list to reflect change
    cheesecake_steps_data = cheesecake_list.display()

    # Return result
    return {
        "removed_label": label,
        "removed_step": removed or "No step removed (not found).",
        "updated_steps": cheesecake_steps_data,
    }


# Lab 5: Infix to Postfix Conversion Implementation
def infix_to_postfix(expression):
    precedence = {"+": 1, "-": 1, "*": 2, "/": 2, "^": 3}
    stack = []
    output = []

    for char in expression:
        if char.isalnum():
            output.append(char)
        elif char == "(":
            stack.append(char)
        elif char == ")":
            while stack and stack[-1] != "(":
                output.append(stack.pop())
            stack.pop()
        else:
            while (
                stack
                and stack[-1] != "("
                and precedence.get(char, 0) <= precedence.get(stack[-1], 0)
            ):
                output.append(stack.pop())
            stack.append(char)

    while stack:
        output.append(stack.pop())

    return "".join(output)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/profile")
def profile():
    return render_template("profile.html")


@app.route("/works")
def works():
    return render_template("works.html")


@app.route("/areaofcircle", methods=["GET", "POST"])
def areaofcircle():
    area = None
    if request.method == "POST":
        try:
            radius = float(request.form.get("radius", ""))
            area = 3.14159 * (radius**2)
        except ValueError:
            area = "Invalid input. Please enter a number."
    return render_template("areaofcircle.html", area=area)


@app.route("/areaoftriangle", methods=["GET", "POST"])
def areaoftriangle():
    area = None
    if request.method == "POST":
        try:
            base = float(request.form.get("base", ""))
            height = float(request.form.get("height", ""))
            area = 0.5 * base * height
        except ValueError:
            area = "Invalid input. Please enter numbers."
    return render_template("areaoftriangle.html", area=area)


@app.route("/touppercase", methods=["GET", "POST"])
def touppercase():
    result = None
    if request.method == "POST":
        input_string = request.form.get("inputString", "")
        result = input_string.upper()
    return render_template("touppercase.html", result=result)


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/cheesecake", methods=["GET", "POST"])
def cheesecake():
    result = None
    if request.method == "POST":
        remove_option = request.form.get("remove_option")
        specific_step = request.form.get("specific_step", "").strip()
        result = ll_cheesecake_recipe(remove_option, specific_step)
    else:
        # Show initial list when first visiting the page
        result = {"updated_steps": cheesecake_steps_data}
    return render_template("cheesecake.html", result=result)


@app.route("/infixpostfix", methods=["GET", "POST"])
def infixpostfix():
    result = None
    if request.method == "POST":
        expression = request.form.get("expression", "")
        result = infix_to_postfix(expression)
    return render_template("infixpostfix.html", result=result)


if __name__ == "__main__":
    app.run(debug=True)
